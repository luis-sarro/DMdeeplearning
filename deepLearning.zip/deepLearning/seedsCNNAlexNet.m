function seedsCNNAlexNet
% NVIDIA(TM) GPU con capacidad 3.0 o mayor.

% Obtenemos infomaci�n del dispositivo gr�fico GPU
deviceInfo = gpuDevice;

% Comprobamos la capacidad de la GPU
computeCapability = str2double(deviceInfo.ComputeCapability);
assert(computeCapability >= 3.0, ...
    'Este ejemplo requiere una GPU con capacidad 3.0 o mayor.')

myDir = 'F:\deepLearning\';

%outputFolder = fullfile(tempdir, 'unedTest'); % define el fichero de salida.
%outputFolder = fullfile(myDir, 'unedTest'); % define el fichero de salida.

%rootFolder = fullfile(outputFolder, 'seedsCategories');
rootFolder = fullfile(myDir, 'seedsCategories');
categories = {'arecaceae', 'arrabidaea','cecropia', 'chromolaena', 'combretum','croton', 'dipteryx', 'eucalipto','faramea', 'hyptis', 'mabea','matayba', 'mimosa','myrcia', 'protium','qualea', 'schinus','senegalia', 'serjania','syagrus','tridax', 'urochloa'};

%%
% Crea un |ImageDatastore| para manejar los datos. 
% Con |ImageDatastore| las imagenes no se cargan en memoria hasta que han
% sido leidas.
imds = imageDatastore(fullfile(rootFolder, categories), 'LabelSource', 'foldernames');

%%
% La variable |imds| contiene las imagenes y las etiquetas
% asociadas a cada imagen. Las etiquetas se asignan de forma autom�tica a partir de lof ficheros. 
% |countEachLabel| da una relaci�n del n�mero de imagenes por etiqueta.
tbl = countEachLabel(imds)

%%Debemos tener el mism n�mero de imagenes pr cada categor�a.
minSetCount = min(tbl{:,2}); % Determina la categor�a con menor cantidad.

% Usamos splitEachLabel para cortar el conjunto.
imds = splitEachLabel(imds, minSetCount, 'randomize');

%Mostramos que todas las clases tienen el mismo n�mero de imagenes.
countEachLabel(imds)

%%
% Mostramos un ejemplode cada una de las categor�as
arecaceae = find(imds.Labels == 'arecaceae', 1);
arrabidaea = find(imds.Labels == 'arrabidaea', 1);
cecropia = find(imds.Labels == 'cecropia', 1);
chromolaena = find(imds.Labels == 'chromolaena', 1);
combretum = find(imds.Labels == 'combretum', 1);
croton = find(imds.Labels == 'croton', 1);
dipteryx = find(imds.Labels == 'dipteryx', 1);
eucalipto = find(imds.Labels == 'eucalipto', 1);
faramea = find(imds.Labels == 'faramea', 1);
hyptis = find(imds.Labels == 'hyptis', 1);
mabea = find(imds.Labels == 'mabea', 1);
matayba = find(imds.Labels == 'matayba', 1);
mimosa = find(imds.Labels == 'mimosa', 1);
myrcia = find(imds.Labels == 'myrcia', 1);
protium = find(imds.Labels == 'protium', 1);
qualea = find(imds.Labels == 'qualea', 1);
schinus = find(imds.Labels == 'schinus', 1);
senegalia = find(imds.Labels == 'senegalia', 1);
serjania = find(imds.Labels == 'serjania', 1);
syagrus = find(imds.Labels == 'syagrus', 1);
tridax = find(imds.Labels == 'tridax', 1);
urochloa = find(imds.Labels == 'urochloa', 1);

figure
subplot(1,22,1);
imshow(readimage(imds,arecaceae))
subplot(1,22,2);
imshow(readimage(imds,arrabidaea))
subplot(1,22,3);
imshow(readimage(imds,cecropia))
subplot(1,22,4);
imshow(readimage(imds,chromolaena))
subplot(1,22,5);
imshow(readimage(imds,combretum))
subplot(1,22,6);
imshow(readimage(imds,croton))
subplot(1,22,7);
imshow(readimage(imds,dipteryx))
subplot(1,22,8);
imshow(readimage(imds,eucalipto))
subplot(1,22,9);
imshow(readimage(imds,faramea))
subplot(1,22,10);
imshow(readimage(imds,hyptis))
subplot(1,22,11);
imshow(readimage(imds,mabea))
subplot(1,22,12);
imshow(readimage(imds,matayba))
subplot(1,22,13);
imshow(readimage(imds,mimosa))
subplot(1,22,14);
imshow(readimage(imds,myrcia))
subplot(1,22,15);
imshow(readimage(imds,protium))
subplot(1,22,16);
imshow(readimage(imds,qualea))
subplot(1,22,17);
imshow(readimage(imds,schinus))
subplot(1,22,18);
imshow(readimage(imds,senegalia))
subplot(1,22,19);
imshow(readimage(imds,serjania))
subplot(1,22,20);
imshow(readimage(imds,syagrus))
subplot(1,22,21);
imshow(readimage(imds,tridax))
subplot(1,22,22);
imshow(readimage(imds,urochloa))

% Cargamos la red pre entrenada AlexNet
net = alexnet()

%%
% |net.Layers| define la arquitectura de la CNN. 

% Mostramos la arquitectura de la red CNN.
net.Layers

%%
% La primera capa define las dimensiones de entrada. El tama�o requerido
% para imagenes es de 227x227x3.

% Comprobamos la primera capa.
net.Layers(1)

%%
%%Las capas intermedias constituyen la mayor parte de la CNN. Estas son una serie
% de capas convolucionales, intercaladas con unidades lineales rectificadas (ReLU)
% y capas max-pooling
%
% La capa final es la capa de clasificaci�n y sus propiedades dependen de
% la tarea de clasificaci�n.

% Comprobamos la �ltima capa.
net.Layers(end)

% N�mero de nombres de clase para las taresas de clasificici�n ImageNet.
numel(net.Layers(end).ClassNames)

%% Pre-proseamiento de las imagenes.
% |net| s�lo puede procesar imagenes RGB de 227 x 227 
% Vamos a pre-procesar las imagenes on the fly. Llamamos |imds.ReadFcn| 
% cada vez que leemos una imagen de |ImageDatastore|.

% Configuramos la funci�n ReadFcn de ImageDatastore.
imds.ReadFcn = @(filename)readAndPreprocessImage(filename);  

%% Preparamos los conjuntos de entrenamiento y test.
% Dividimos los datos en conjuntos entrenamiento y validaci�n. El 30% de
% las imagenes de cada conjunto para entrenamiento y el 70% para
% validaci�n.
% Efectuamos una selecci�n aleatoria de los datos para evitar bias en los
% resultados.
% Estos conjutos son procesados por la CNN.

[trainingSet, testSet] = splitEachLabel(imds, 0.3, 'randomize');

%% Extraemos las caracter�sticas en el entrenamiento utilizando la CNN.
% Cada capa de la CNN produce una respuesta, o activaci�n, a una imagen de
% entrada. S�lo unas cuantas capas de la CNN son aptas para la extracci�n
% de caracter�sticas de las imagenes. Los layers al comienzo de la red
% capturan las caracter�sticas b�sicas de las imagenes. 

% Obtenemos los pesos de la red para la segunda capa convolucional.
w1 = net.Layers(2).Weights;

w1 = mat2gray(w1);
w1 = imresize(w1,5); 

figure
montage(w1)
title('First convolutional layer weights')

%%
% Observamos c�mo la primera capa de la red ha aprendido los filtros para
% captura caracter�sticas b�sicas. Estas caracter�sticas primitivas son 
% procesadas por capas de red m�s profundas que forman caracter�sticas de 
% imagen de nivel superior. 
%
% La capa justo antes de la clasificaci�n capa es un buen lugar para 
% extraer caracter�sticas de una de las capas m�s profundas.
% Esta capa se denomina 'fc7'. 
% Vamos a extraer las funciones de entrenamiento utilizando esa capa.

featureLayer = 'fc7';
trainingFeatures = activations(net, trainingSet, featureLayer, ...
    'MiniBatchSize', 32, 'OutputAs', 'columns');

%% Train A Multiclass SVM Classifier Using CNN Features
%% Entrenamos un clasificador con un SVM multiclase utilizando las
% caracter�sticas de la CNN

% Obtenemos las etiquetas de entrenamiento de trainingSet
trainingLabels = trainingSet.Labels;

% Entrenamos el clasificador.
classifier = fitcecoc(trainingFeatures, trainingLabels, ...
    'Learners', 'Linear', 'Coding', 'onevsall', 'ObservationsIn', 'columns');

%% Evaluamos el clasificador

% Extraemos las caracter�sticas del conjunto de test de la CNN
testFeatures = activations(net, testSet, featureLayer, 'MiniBatchSize',32);

% Pasamos las caracter�sticas de las imagenes de la CNN al clasificador.
predictedLabels = predict(classifier, testFeatures);

% Obtenemos las etiquetas
testLabels = testSet.Labels;

% Mostramos la matriz de confusi�n.
confMat = confusionmat(testLabels, predictedLabels);

% Convertimos la matriz de confusi�n a porcentajes.
confMat = bsxfun(@rdivide,confMat,sum(confMat,2))

% Mostramos la precisi�n media
mean(diag(confMat))

%% Probamos con nuevas imagenes.
myFolder = 'F:\deepLearning\';
newImage = fullfile(myFolder, 'samples', 'urochloa_(18).jpg');

% Pre-procesamos la imagen.
img = readAndPreprocessImage(newImage);

% Extraemos las caracter�sticas de la imagen usando la CNN
imageFeatures = activations(net, img, featureLayer);

% Hacemos la predicci�n
label = predict(classifier, imageFeatures)

end
